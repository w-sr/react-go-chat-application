import ChatInput from "./ChatInput";

export default ChatInput;