import ChatHistory from "./ChatHistory";

export default ChatHistory;